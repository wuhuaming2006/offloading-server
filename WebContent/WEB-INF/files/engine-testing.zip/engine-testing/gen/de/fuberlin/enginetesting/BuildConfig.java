/** Automatically generated file. DO NOT MODIFY */
package de.fuberlin.enginetesting;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}